<!doctype html>
<html lang="en">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="<?php echo e($aplikasi->singkatan); ?>" />
	<meta name="description" content="<?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?> - <?php echo $__env->yieldContent('title'); ?>" />
	<link rel="canonical" href="<?php echo e(url()->full()); ?>" />
	<meta property="og:locale" content="id_ID" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="<?php echo $__env->yieldContent('title'); ?>" />
	<meta property="og:description" content="<?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?> - <?php echo $__env->yieldContent('title'); ?>" />
	<meta property="og:url" content="<?php echo e(url()->full()); ?>" />
	<meta property="og:site_name" content="<?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?> - <?php echo $__env->yieldContent('title'); ?>" />
	<meta property="article:modified_time" content="<?php echo e(date('Y-m-d H:i:s')); ?>" />
	<meta property="og:image" content="<?php echo $__env->yieldContent('img'); ?>" />
	<meta name="twitter:card" content="summary" />
	<meta name="twitter:label1" content="Est. reading time" />
	<meta name="twitter:data1" content="3 minutes" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link
      href="https://fonts.googleapis.com/css2?family=Handlee&family=Nunito&display=swap"
      rel="stylesheet"
    />

    <!-- Font Awesome -->
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css"
      rel="stylesheet"
    />

	<!-- Flaticon Font -->
    <link href="<?php echo e(URL::asset('frontend/lib/flaticon/font/flaticon.css')); ?>" rel="stylesheet" />

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(URL::asset('frontend/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(URL::asset('frontend/lib/lightbox/css/lightbox.min.css')); ?>" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(URL::asset('frontend/css/style.css')); ?>" rel="stylesheet" />
	
<?php if($aplikasi->file_favicon): ?>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset($aplikasi->file_favicon->url_stream)??''); ?>">
	<title><?php echo $__env->yieldContent('title'); ?> | <?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?></title>
<?php endif; ?>
<?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
		<?php echo $__env->make('layouts.frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<?php echo $__env->yieldContent('content'); ?>
		<?php echo $__env->make('layouts.frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- <div class="copyright-text text-center">
        <p>© <?php echo e($aplikasi->singkatan.' '.$aplikasi->daerah); ?>. <a href="https://diskominfotik.bengkaliskab.go.id/" target="_blank">Tim IT Diskominfotik</a></p>
    </div> -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary p-3 back-to-top"
      ><i class="fa fa-angle-double-up"></i
    ></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(URL::asset('frontend/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/lib/isotope/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/lib/lightbox/js/lightbox.min.js')); ?>"></script>

    <!-- Contact Javascript File -->
    <script src="<?php echo e(URL::asset('frontend/mail/jqBootstrapValidation.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('frontend/mail/contact.js')); ?>"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(URL::asset('frontend/js/main.js')); ?>"></script>

	<?php echo $__env->yieldPushContent('js'); ?>
	

</body>
</html><?php /**PATH D:\laragon\www\dwprs\resources\views/layouts/frontend/main.blade.php ENDPATH**/ ?>