<div class="pos-bottom pos-left pos-right p-3 text-center text-white">
    <?php echo e(date('Y')); ?> © <?php echo e(config('master.aplikasi.nama')); ?>. All Right Reserved
</div>
<?php /**PATH D:\laragon\www\dwprs\resources\views/auth/footer.blade.php ENDPATH**/ ?>