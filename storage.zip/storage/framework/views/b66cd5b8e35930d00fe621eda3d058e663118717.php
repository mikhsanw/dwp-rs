
<?php $__env->startPush('title', 'Akses Menu dari '. $aksesgrup->nama); ?>
<?php $__env->startPush('header', 'Akses Menu dari '. $aksesgrup->nama); ?>
<?php $__env->startPush('tombol'); ?>
<a href="<?php echo e(URL::asset($url_admin.'/aksesgrup')); ?>" class="waves-effect waves-light btn bg-gradient-danger text-white py-2 px-3 b-0 tambah">
	Kembali
</a>
<a href="#tambah" id="editable_table_new" aksesgrup-id="<?php echo e($aksesgrup->id); ?>" class="waves-effect waves-light btn bg-gradient-secondary text-white py-2 px-3 b-0 tambah">
	Kelola
</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<table id="datatable" class="table table-striped table-bordered display" style="width:100%">
			<thead class="bg-primary-600">
				<tr>
					<th>Menu</th>
					<th>Sub Menu</th>
				</tr>
			</thead>
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('layouts.backend.js.datatable-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/'.$aksesgrup->id.'/datatables.js')); ?>"></script>

<link rel="stylesheet" href="<?php echo e(url('backend/assets/vendor_plugins/iCheck/icheck.min.js')); ?>">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\dwprs\resources\views/backend/aksesmenu/index.blade.php ENDPATH**/ ?>