<?php if($data->children->count() > 0 && $data->status != 4): ?>
<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown"><?php echo e($data->nama); ?></a>
<div class="dropdown-menu rounded-0 m-0">
    <?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('layouts.frontend.menu', ['data'=>$sub], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
    <?php if($data->status==2): ?>
    <a class="nav-link" href="<?php echo e($data->link); ?>"><?php echo e($data->nama); ?></a>
    <?php else: ?>
    <a class="nav-link" href="<?php echo e(url('/company/page/'.$data->id.'/'.Help::generateSeoURL($data->nama))); ?>"><?php echo e($data->nama); ?></a>
    <?php endif; ?>

<?php endif; ?>
<?php /**PATH D:\laragon\www\dwprs\resources\views/layouts/frontend/menu.blade.php ENDPATH**/ ?>