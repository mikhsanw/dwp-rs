<?php echo Form::open(array('id' => 'frmOji', 'class' => 'form account-form', 'method' => 'post')); ?>

<div class="row">
	<?php echo $__env->make('backend.aksesmenu.menu.menu',['menu'=>$menu,'aksesgrup'=>$aksesgrup], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo Form::hidden('url', URL::previous(), array('id' => 'url')); ?>

	<?php echo Form::hidden('id', $aksesgrup->id, array('id' => 'id')); ?>

</div>
<div class="row">
	<div class="col-md-12">
		<span class="pesan"></span>
	</div>
</div>
<?php echo Form::close(); ?>

<script src="<?php echo e(URL::asset(config('master.aplikasi.author').'/aksesmenu/ajax.js')); ?>"></script>
<script src="<?php echo e(URL::asset(config('master.aplikasi.author').'/js/ajax.js')); ?>"></script>
<?php /**PATH D:\laragon\www\dwprs\resources\views/backend/aksesmenu/tambah.blade.php ENDPATH**/ ?>