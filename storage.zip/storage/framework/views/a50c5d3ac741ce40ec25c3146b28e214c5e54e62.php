<!-- Navbar Start -->
<div class="container-fluid bg-light position-relative shadow">
      <nav
        class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0 px-lg-5"
      >
        <a
          href=""
          class="navbar-brand font-weight-bold text-secondary"
          style="font-size: 50px"
        >
          <!-- <i class="flaticon-043-teddy-bear"></i> -->
          
            <?php if($aplikasi->file_logo || $aplikasi->file_favicon): ?>
            <img
              src="<?php echo e($aplikasi->file_logo?asset($aplikasi->file_logo->url_stream):asset($aplikasi->file_favicon->url_stream)); ?>"
              class="img-fluid"
              style="height: 60px"
            />
            <?php endif; ?>
          
        </a>
        <button
          type="button"
          class="navbar-toggler"
          data-toggle="collapse"
          data-target="#navbarCollapse"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-between"
          id="navbarCollapse"
        >
          <div class="navbar-nav font-weight-bold mx-auto py-0">
		  	<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e(is_string($val) ? $val : '#'); ?>" class="nav-item nav-link"><?php echo e($key); ?></a>
				<?php if(!is_string($val)): ?>
				<div class="nav-item dropdown">
					<?php $__currentLoopData = $val; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keydata => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php echo $__env->make('layouts.frontend.menu',['data'=>$data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </nav>
    </div>
    <!-- Navbar End --><?php /**PATH D:\laragon\www\dwprs\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>