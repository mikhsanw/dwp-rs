    <ol class="dd-list">
        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="dd-item dd3-item" data-id="<?php echo e($mn->id); ?>">
                <div class="dd-handle dd3-handle">
                </div>
                <div class="dd3-content" title="<?php echo e($mn->detail['title'] ?? ''); ?>">
                    <?php if($mn->icon): ?> <span class="<?php echo e($mn->icon); ?>"></span> <?php endif; ?> <?php echo e($mn->nama); ?>

                    <div class="pull-right">
                        <a class="edit ubah" data-toggle="tooltip" data-placement="top" title="Ubah data menu" menu-id="<?php echo e($mn->id); ?>" href="#edit-<?php echo e($mn->id); ?>">
                            <i class="fa fa-edit text-warning"> </i>
                        </a>&nbsp; &nbsp;
                        <a class="delete hidden-xs hidden-sm hapus" data-toggle="tooltip" data-placement="top" title="Hapus Menu" menu-id="<?php echo e($mn->id); ?>" href="#hapus-<?php echo e($mn->id); ?>">
                            <i class="fa fa-trash text-danger"> </i>
                        </a>
                    </div>
                </div>
                <?php echo $__env->make('backend.menu.list-menu.list-menu', ['menu'=>$mn->children], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>

<?php /**PATH D:\laragon\www\dwprs\resources\views/backend/menu/list-menu/list-menu.blade.php ENDPATH**/ ?>