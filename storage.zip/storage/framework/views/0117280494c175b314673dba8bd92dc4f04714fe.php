
<?php $__env->startPush('title',ucwords(strtolower($halaman->nama))); ?>
<?php $__env->startPush('header'); ?>
	<a href="<?php echo e(url('halaman')); ?>"><?php echo e($halaman->nama); ?></a> > 
	<?php if($data->parentRecursive): ?>
		<?php echo $data->createHeaderTree($data->parentRecursive); ?>

		<?php echo e($data->nama); ?>

	<?php else: ?>
		<?php echo e($data->nama); ?>

	<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('tombol'); ?>
<a class="waves-effect waves-light btn bg-gradient-danger text-white py-2 px-3 Kembali" href="<?php echo e(url()->previous()); ?>">
	Kembali
</a>
<button class="waves-effect waves-light btn bg-gradient-primary text-white py-2 px-3 tambah-halaman">
	Tambah
</button>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<table id="datatable" class="table table-striped table-bordered display" style="width:100%">
			<thead class="bg-primary">
				<tr>
					<th width="5%">No</th>
					<th class="text-center">Menu</th>
					<th class="text-center">Kelola</th>
					<th width="50px" class="text-center" tabindex="0" rowspan="1" colspan="1">Aksi</th>
				</tr>
			</thead>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('layouts.backend.js.datatable-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/js/'.$halaman->link.'/'.$halaman->kode.'/jquery-crud.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/'.$data->id.'/datatables_detail.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/'.$data->id.'/jquery-detail.js')); ?>"></script>
<script src="<?php echo e(asset('backend/fromplugin/summernote/summernote.js')); ?>" async=""></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
<link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/fromplugin/summernote/summernote.css')); ?>">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\dwprs\resources\views/backend/halaman/detail.blade.php ENDPATH**/ ?>