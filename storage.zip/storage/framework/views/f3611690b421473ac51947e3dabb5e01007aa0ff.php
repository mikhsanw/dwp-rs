
<?php $__env->startPush('title','Dashboard'); ?>
<?php $__env->startPush('header','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<section class="content">
	<h6 class="pull-right"><?php echo e(date("l, d F Y")); ?></h6>
		<div class="box">
			<div class="box-header with-border">
				<h4 class="box-title d-block text-left"><i class="fas fa-home"></i> Dashboard</h4>          
			</div>
		</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\dwprs\resources\views/backend/beranda/index.blade.php ENDPATH**/ ?>