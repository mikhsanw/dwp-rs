<li class="<?php echo e((count($mn->children) > 0 ? 'treeview' :'').' '.$mn->active($mn->kode)); ?>">
    <a href="<?php echo e(count($mn->children) > 0 ? '#' : url(ltrim($url_admin.'/'.$mn->link, '/'))); ?>">
    <i class="<?php echo e($mn->icon); ?>"><span class="path1"></span><span class="path2"></span></i>
    <span><?php echo e($mn->nama); ?></span>
    <?php if(count($mn->children) > 0): ?>
        <span class="pull-right-container">
            <i class="fa fa-angle-right pull-right"></i>
        </span>
    <?php endif; ?>
    </a>
    <?php if(count($mn->children) > 0): ?>
        <ul class="treeview-menu">
            <?php $__currentLoopData = $mn->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($sub->tampil == 1 && $sub->status == 1): ?>
                    <?php if($sub->checkAksesmenu(Auth::user()->aksesgrup_id)): ?>
                        <?php echo $__env->make('layouts.backend.sidebar_item.submenu', ['mn'=>$sub], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
        </ul>
    <?php endif; ?>
</li><?php /**PATH D:\laragon\www\dwprs\resources\views/layouts/backend/sidebar_item/submenu.blade.php ENDPATH**/ ?>