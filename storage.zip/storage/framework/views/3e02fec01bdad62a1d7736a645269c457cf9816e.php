<li style="list-style: none">
    <?php echo Form::checkbox('menu[]', $mn->id, $mn->checkAksesmenu($aksesgrup->id), array('id' => 'icheck-input menu'.$mn->id, 'menu-id' => $mn->id, 'class' => 'icheck-input menu'.$mn->id)); ?>

    &nbsp;&nbsp;
    <label for="icheck-input menu<?php echo e($mn->id); ?>"><?php echo e($mn->nama); ?></label>
    <?php if(count($mn->children)): ?>
        <ul>
            <?php $__currentLoopData = $mn->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('backend.aksesmenu.menu.sub-menu',['mn'=>$cmn,'aksesgrup'=>$aksesgrup], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH D:\laragon\www\dwprs\resources\views/backend/aksesmenu/menu/sub-menu.blade.php ENDPATH**/ ?>