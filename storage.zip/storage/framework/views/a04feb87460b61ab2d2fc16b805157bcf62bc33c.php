
<?php $__env->startSection('title', 'Galeri '.$jenis); ?>
<?php $__env->startSection('img', asset($aplikasi->file_logo->url_stream)); ?>
<?php $__env->startSection('content'); ?>
<!-- Header Start -->
<div class="container-fluid bg-primary mb-5">
    <div
    class="d-flex flex-column align-items-center justify-content-center"
    style="min-height: 300px"
    >
    <h3 class="display-3 font-weight-bold text-white">Galeri</h3>
    <div class="d-inline-flex text-white">
        <p class="m-0"><a class="text-white" href="<?php echo e(url('/')); ?>">Beranda</a></p>
        <p class="m-0 px-2">/</p>
        <p class="m-0">Galeri</p>
    </div>
    </div>
</div>
<!-- Header End -->
<!-- Gallery Start -->
<div class="container-fluid pt-5" style="padding-bottom:12rem">
    <div class="container">
        <div class="row portfolio-container">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 col-md-6 portfolio-item ">
            <div class="position-relative overflow-hidden mb-2">
            <img class="img-fluid w-100" src="<?php echo e($foto->file->url_stream); ?>" alt="" />
            <div class="portfolio-btn bg-primary d-flex align-items-center justify-content-center">
                <a href="<?php echo e($foto->file->url_stream); ?>" data-lightbox="portfolio">
                <i class="fa fa-plus text-white" style="font-size: 60px"></i>
                </a>
            </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
    <!-- Gallery End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\dwprs\resources\views/frontend/beranda/galeri.blade.php ENDPATH**/ ?>